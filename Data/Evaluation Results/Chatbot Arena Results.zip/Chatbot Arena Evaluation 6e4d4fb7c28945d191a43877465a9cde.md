# Chatbot Arena Evaluation

[Human Evaluation](Human%20Evaluation%20d2ce601fc6ad408fb72e2630f192be5a.csv)